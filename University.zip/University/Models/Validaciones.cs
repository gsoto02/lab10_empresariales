﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace University.Models
{
    [MetadataType(typeof(StudentValidacion))]
    public partial class Student
    {
    }

    public class StudentValidacion
    {
        [Required(ErrorMessage = "Ingrese los apellidos")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Ingrese los nombres")]
        public string FirstName { get; set; }

        [EmailAddress(ErrorMessage = "Ingrese un correo válido")]
        public string Email { get; set; }
    }
}
