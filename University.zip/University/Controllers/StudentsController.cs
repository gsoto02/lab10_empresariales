﻿
using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using University.Models;

namespace University.Controllers
{
    public class StudentsController : Controller
    {
        private UniversityDBEntities db = new UniversityDBEntities();

        // LISTAR ESTUDIANTES
        public ActionResult Index()
        {
            return View(db.Student.ToList());
        }

        // VER DETALLES
        public ActionResult Details(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Student student = db.Student.Find(id);

            if (student == null)
                return HttpNotFound();

            return View(student);
        }

        // MOSTRAR FORMULARIO DE REGISTRO
        public ActionResult Create()
        {
            return View();
        }

        // GUARDAR NUEVO ESTUDIANTE
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(
            [Bind(Include = "StudentID,LastName,FirstName,Email,EnrollmentDate")]
            Student student)
        {
            if (ModelState.IsValid)
            {
                db.Student.Add(student);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(student);
        }

        // MOSTRAR FORMULARIO DE EDICIÓN
        public ActionResult Edit(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Student student = db.Student.Find(id);

            if (student == null)
                return HttpNotFound();

            return View(student);
        }

        // GUARDAR CAMBIOS
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(
            [Bind(Include = "StudentID,LastName,FirstName,Email,EnrollmentDate")]
            Student student)
        {
            if (ModelState.IsValid)
            {
                db.Entry(student).State = EntityState.Modified;
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(student);
        }

        // MOSTRAR CONFIRMACIÓN DE ELIMINACIÓN
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Student student = db.Student.Find(id);

            if (student == null)
                return HttpNotFound();

            return View(student);
        }

        // ELIMINAR ESTUDIANTE
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Student student = db.Student.Find(id);

            if (student == null)
                return HttpNotFound();

            // Evitar eliminar estudiantes con matrículas relacionadas
            bool tieneMatriculas = db.Enrollment
                .Any(e => e.StudentID == id);

            if (tieneMatriculas)
            {
                ModelState.AddModelError("",
                    "No se puede eliminar el estudiante porque tiene matrículas registradas.");

                return View("Delete", student);
            }

            db.Student.Remove(student);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                db.Dispose();

            base.Dispose(disposing);
        }
    }
}
